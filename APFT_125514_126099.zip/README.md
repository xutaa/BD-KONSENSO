# BD-KONSENSO
Database Fundamentals Project for KONSENSO
